# Minerva Personal Assistant
 The project involves training a voice and image recognition algorithm to serve as a personal assistant for user-defined machine learning questions. The system will be named Minerva, it will interpret the user's voice and image, and make decisions accordingly.
